---
id: post2
title: Post 2
author: Author 2
summary: Summary 2
date: 1972-01-01
tags:
    - tagged
---

**Content 2**