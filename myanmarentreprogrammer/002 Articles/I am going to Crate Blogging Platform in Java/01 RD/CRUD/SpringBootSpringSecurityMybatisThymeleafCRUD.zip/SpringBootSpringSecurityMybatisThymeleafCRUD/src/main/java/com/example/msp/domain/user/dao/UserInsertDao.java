package com.example.msp.domain.user.dao;

import com.example.msp.database.entity.Users;

public interface UserInsertDao {

	int insertUser(Users user);
}
