package com.example.msp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSpringSecurityMybatisThymeleafCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSpringSecurityMybatisThymeleafCrudApplication.class, args);
	}
}
