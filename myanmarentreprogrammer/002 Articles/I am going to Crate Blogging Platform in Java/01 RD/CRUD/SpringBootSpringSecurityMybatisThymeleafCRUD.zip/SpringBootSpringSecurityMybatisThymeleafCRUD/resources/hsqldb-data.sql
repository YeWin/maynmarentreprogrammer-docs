INSERT INTO country VALUES (1,'Afghanistan','2006-02-15 04:44:00');

INSERT INTO city VALUES
  (1,'A Corua (La Corua)',1,'2006-02-15 04:45:25'),
  (2,'Abha',1,'2006-02-15 04:45:25');

