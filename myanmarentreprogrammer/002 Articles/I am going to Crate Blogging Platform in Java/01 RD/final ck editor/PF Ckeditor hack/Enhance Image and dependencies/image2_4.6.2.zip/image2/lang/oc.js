/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'oc', {
	alt: 'Tèxte alternatiu',
	btnUpload: 'Mandar sul servidor',
	captioned: 'Imatge amb legenda',
	captionPlaceholder: 'Legenda',
	infoTab: 'Informacions sus l\'imatge',
	lockRatio: 'Conservar las proporcions',
	menu: 'Proprietats de l\'imatge',
	pathName: 'imatge',
	pathNameCaption: 'legenda',
	resetSize: 'Reïnicializar la talha',
	resizer: 'Clicar e lisar per redimensionar',
	title: 'Proprietats de l\'imatge',
	uploadTab: 'Mandar',
	urlMissing: 'L\'URL font de l\'imatge es mancanta.',
	altMissing: 'Lo tèxte alternatiu es mancant.'
} );
