/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'pt-br', {
	anchor: 'Âncora',
	flash: 'Animação em Flash',
	hiddenfield: 'Campo Oculto',
	iframe: 'IFrame',
	unknown: 'Objeto desconhecido'
} );
