/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'eu', {
	anchor: 'Aingura',
	flash: 'Flash animazioa',
	hiddenfield: 'Ezkutuko eremua',
	iframe: 'IFrame-a',
	unknown: 'Objektu ezezaguna'
} );
