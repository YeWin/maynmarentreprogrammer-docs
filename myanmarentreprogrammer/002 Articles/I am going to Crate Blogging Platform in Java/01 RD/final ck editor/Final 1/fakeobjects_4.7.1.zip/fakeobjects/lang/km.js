/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'km', {
	anchor: 'យុថ្កា',
	flash: 'Flash មាន​ចលនា',
	hiddenfield: 'វាល​កំបាំង',
	iframe: 'IFrame',
	unknown: 'វត្ថុ​មិន​ស្គាល់'
} );
